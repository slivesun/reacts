# wepack4+react
基于wepack4+react构建的模板，可以快速使用

根据个人所需，里面的注释的内容可以打开或者删除
## 注意
目前此项目配置清除插件会把打包目录清空

可以根据个人需要根据开发环境或者生产环境抽离出module和plugins进行单独文件配置

可以参考blog-admin下webpack_config文件下的文件



## 1.安装 

下载到本地

`git clone git@github.com:944832260/webpack4-react.git`

安装依赖

`npm i`

开发命令

`npm run dev`

打包生产命令

`npm run build`


