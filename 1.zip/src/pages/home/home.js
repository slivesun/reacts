import * as React from "react";
import "./home.less";



class Home extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
		}
	}


	UNSAFE_componentWillMount() {

	}

	componentDidMount() {
	}
	componentDidUpdate() {
		
	}


	render() {
		let { policyList } = this.state;
		return (
			<div id='Home'>
					465464
			</div>
		);
	}
}


export default Home
